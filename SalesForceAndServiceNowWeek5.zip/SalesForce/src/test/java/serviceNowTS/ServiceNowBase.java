package serviceNowTS;

import org.testng.annotations.BeforeMethod;
import io.restassured.RestAssured;

public class ServiceNowBase {

	@BeforeMethod
	public void BaseConfig() {
		System.out.println("Hi Dasvin!");
		RestAssured.baseURI = "https://dev140626.service-now.com/api/now/table/";
		RestAssured.authentication = RestAssured.basic("admin", "YaO9-A0opfR*");
	}

}
