package serviceNowTS;

import org.testng.annotations.Test;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import utils.APIUtils;

public class CreateRequest extends ServiceNowBase {
	
	RequestSpecification request;
	Response response;
	APIUtils obj = new APIUtils();
	
	@Test
	public void Post() {
		
		request = RestAssured.given().contentType(ContentType.JSON).when().body("{\r\n"
				+ "    \"short_description\":\"My first record in api change request table\",\r\n"
				+ "    \"description\":\"10win created the this record for practice purpose\",\r\n"
				+ "    \"category\" : \"software\"\r\n"
				+ "}");
		response = request.post("change_request");
		response.then().assertThat().log().ifError();
		obj.validateStatusCode(response, 201);
		obj.validateResponseContainsString(response, "result.number", "CHG");
		obj.validateJsonKey(response, "correlation_id");
		obj.CheckFails();
		
	}
	
}
