package testScripts;

import org.testng.annotations.*;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import utils.APIUtils;

public class BaseSetup extends APIUtils {
	
	String token;
	
	@BeforeClass
	public void beforeTest() {
		
		RequestSpecification request = RestAssured.given().contentType(ContentType.URLENC)
				.formParam("grant_type", "password")
				.formParam("client_id", "3MVG9n_HvETGhr3A0LdjlSwYq6VXl7ftP_qtXc7dhY_o.Amd1mnWQzaUiYmGmp.JEibCCYu4_V6dEG.Bdt.Y_")
				.formParam("client_secret", "8D2EE135AA4FD467C1E6FDF25A30503AF6508177334C0AD6C8ED1CD55F751A9E")
				.formParam("username", "10win@gmail.com")
				.formParam("password", "Dasvin@2404");
		Response response = request.post("https://login.salesforce.com/services/oauth2/token");
		response.prettyPrint();
		token = response.jsonPath().getString("access_token");
		System.out.println(token);

	}
	
	@BeforeMethod
	public void URIandAuth() {
		RestAssured.baseURI = "https://demo-18c-dev-ed.develop.my.salesforce.com/services/data/v22.0/sobjects";
		RestAssured.authentication = RestAssured.oauth2(token);
	}

}
