package testScripts;

import java.io.File;
import java.util.ArrayList;
import org.testng.annotations.Test;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class PostDD extends BaseSetup {
	
	ArrayList<String> ids = new ArrayList<String>();
	RequestSpecification request;
	Response response;
	
	@Test
	public void postDD() {
	File data = new File(System.getProperty("user.dir")+"/src/test/resources/PostData");
	File[] Files = data.listFiles();
	for(int i=0; i<Files.length; i++) {
		System.out.println(Files[i]);
		request = RestAssured.given().contentType(ContentType.JSON).when().body(Files[i]);
		response = request.post("/Contact");
		response.then().assertThat().statusCode(201);
		response.prettyPrint();
		String id = response.jsonPath().get("id");
		ids.add(id);
		}
	for(int i=0; i<ids.size(); i++) {
		System.out.println(ids.get(i));
	}
	}
	
	@Test (dependsOnMethods = {"testScripts.PostDD.postDD"})
	public void DeteleMultileIds() {
		for(int i=0; i<ids.size(); i++) {
			request = RestAssured.given();
			response = request.delete("/Contact/"+ids.get(i));
			response.then().assertThat().statusCode(204);
		}
	}
	
}
	

