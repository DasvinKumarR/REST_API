package testScripts;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class CreateContact extends BaseSetup{
	
	RequestSpecification request;
	Response response;
	String saleId;

	@Test
	public void postContact() {
		request = RestAssured.given().contentType(ContentType.JSON).when().body("{\r\n"
				+ "    \"FirstName\": \"Dasvin\",\r\n"
				+ "    \"LastName\": \"Kumar\"\r\n"
				+ "}").log().all();
		response = request.post("/Contact");
		response.then().assertThat().statusCode(201).log().all();
		saleId = response.jsonPath().get("id");
		System.out.println(saleId);
	}
	
	@Test (dependsOnMethods = {"testScripts.CreateContact.postContact"})
	public void updateContact() {
		request = RestAssured.given().contentType(ContentType.JSON).when().body("{\r\n"
				+ "    \"MailingState\": \"Tamil Nadu\"\r\n"
				+ "}").log().all();
		response = request.patch("/Contact/"+saleId);
		response.then().assertThat().statusCode(204).log().all();
	}
	
	@Test (dependsOnMethods = {"testScripts.CreateContact.updateContact"})
	public void deleteContact() {
		request = RestAssured.given();
		response = request.delete("/Contact/"+saleId);
		response.then().assertThat().statusCode(204).log().all();
	}
	
}
