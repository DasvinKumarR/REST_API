package utils;

import org.hamcrest.Matchers;
import org.testng.Assert;
import io.restassured.response.Response;

public class APIUtils {
	
	int errorCount = 0;
	
	public void validateStatusCode(Response response, int code) {
		try {
			response.then().assertThat().statusCode(code);
		}catch (AssertionError e) {
			System.out.println("Status Code Assertion Failed, Actual Status code is:" + response.getStatusCode());
			errorCount++;
		}
	}
	
	public void validateResponseContainsString(Response response, String Path, String Content) {
		try {
			response.then().assertThat().body(Path, Matchers.containsString(Content));
		}catch(AssertionError e) {
			System.out.println(Path+" Doesn't Contains String: "+ Content);
			errorCount++;
		}
	}
	
	public void validateJsonKey(Response response, String Key) {
		
		String value = response.asPrettyString();
		boolean hasKey = value.contains(Key);
		if(hasKey != true) {
			System.out.println("Response not contains Key: "+Key);
			errorCount++;
		}
		
	}
	
	public void CheckFails() {
		if(errorCount>0) {
			Assert.fail();
			errorCount = 0;
		}
	}

}
