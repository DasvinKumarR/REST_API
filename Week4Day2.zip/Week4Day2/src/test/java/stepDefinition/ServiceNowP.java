package stepDefinition;

import static org.testng.Assert.assertEquals;

import externalSource.baseNeeds;
import io.cucumber.java.en.*;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;


public class ServiceNowP extends baseNeeds{

	@When("add random Alphabets in short_description body")
	public void add_random_alphabets_in_short_description_body() {
	   request = RestAssured.given().contentType(ContentType.JSON).when().body("{\r\n"
	   		+ "\"short_description\": \"Created\"\r\n"
	   		+ "}").log().all();
	}

	@And("send post request")
	public void send_post_request() {
		response = request.post("change_request");
	}

	@Then("Validate create response")
	public void validate_create_response() {
	  response.then().assertThat().statusCode(201);
	  sys_value = response.body().jsonPath().getString("result.sys_id");
	  //System.out.println(sys_value);
	  String task_no = response.body().jsonPath().getString("result.task_effective_number");
	  int stringSize = task_no.length();
	  //System.out.println(stringSize);
	  assertEquals(10, stringSize);
	}
	
}
