package stepDefinition;

import org.hamcrest.Matchers;

import externalSource.baseNeeds;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;

public class ServiceNowPu extends baseNeeds {

	@When("add modified short desc data")
	public void add_modified_short_desc_data() {
		   request = RestAssured.given().contentType(ContentType.JSON).when().body("{\r\n"
			   		+ "\"short_description\": \"asdfghjklm\"\r\n"
			   		+ "}").log().all();
	}

	@And("Send put request")
	public void send_put_request() {
	    response = request.put("change_request/" + sys_value);
	}

	@Then("validate put response")
	public void validate_put_response() {
	    response.then().assertThat().statusCode(200);
	    response.then().assertThat().body("result.short_description", Matchers.containsString("asdfghjklm"));
	}
	
}
