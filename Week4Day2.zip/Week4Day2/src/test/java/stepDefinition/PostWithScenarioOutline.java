package stepDefinition;

import org.hamcrest.Matchers;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class PostWithScenarioOutline {
	
	RequestSpecification request;
	Response response;
	
	@When("^send request with body (.*) and (.*)$")
	public void send_request_with_body_this_is_first_and_software(String short_desc, String category) {
	   request = RestAssured.given().contentType(ContentType.JSON).body("{\r\n"
	   		+ "    \"short_description\":\""+ short_desc +"\",\r\n"
	   		+ "    \"category\" : \""+ category +"\"\r\n"
	   		+ "}").log().all();
	   response = request.post("change_request");
	}

	@Then("^validate reponse (.*) and (.*)$")
	public void validate_reponse_this_is_first_and_software(String short_desc, String category) {
		response.then().assertThat().statusCode(201);
		response.then().assertThat().body("result.short_description", Matchers.containsString(short_desc));
		response.then().assertThat().body("result.category", Matchers.containsString(category));
	}


}
