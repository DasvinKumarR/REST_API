package stepDefinition;

import io.cucumber.java.en.*;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class GetAllIncidentStep {
	
	RequestSpecification request;
	Response response;

//	@Given("set end point")
//	public void set_end_point() {
//	   RestAssured.baseURI = "https://dev140626.service-now.com/api/now/table/";
//	}
//
//	@And("set authentication")
//	public void set_authentication() {
//		RestAssured.authentication = RestAssured.basic("admin", "YaO9-A0opfR*");
//	}
	
	@When("Query param {string} and {string}")
	public void query_param_and(String key, String value) {
	    request = RestAssured.given().queryParam(key, value).log().all();
	}

	@And("send get request")
	public void send_get_request() {
		//request = RestAssured.given().log().all();
	    response = request.get("change_request");
	}

	@Then("validate response")
	public void validate_response() {
	    response.then().log().all();
	    response.then().assertThat().statusCode(200);
	}
	
}
