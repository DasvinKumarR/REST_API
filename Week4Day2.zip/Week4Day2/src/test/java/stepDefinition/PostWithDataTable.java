package stepDefinition;

import java.util.List;

import org.hamcrest.Matchers;
import externalSource.baseNeeds;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.*;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;

public class PostWithDataTable extends baseNeeds {
	
	@When("set body with data")
	public void set_body_with_data() {
		request = RestAssured.given().contentType(ContentType.JSON).when().body("{\r\n"
				+ "\"short_description\": \"Created\"\r\n"
				+ "}").log().all();
	}

	@And("send create request")
	public void send_create_request() {
		response = request.post("change_request");
	}

	@Then("validate response body")
	public void validate_response_body(DataTable dt) {
	    List<List<String>> data = dt.cells();
	    response.then().assertThat().statusCode(201);
	    for(int i=0; i <= data.size()-1; i++) {
	    	response.then().assertThat().body("result."+data.get(i).get(0), Matchers.containsString(data.get(i).get(1)));
	    }
	}

}
