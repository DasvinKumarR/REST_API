package stepDefinition;

import externalSource.baseNeeds;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;

public class ServiceNowD extends baseNeeds {

	@When("send delete request")
	public void send_delete_request() {
		request = RestAssured.given().log().all();
	    response = request.delete("change_request/" + sys_value);
	}

	@Then("validate delete status code")
	public void validate_delete_status_code() {
	   response.then().assertThat().statusCode(204);
	   response.then().assertThat().statusLine("HTTP/1.1 204 No Content");
	}
	
}
