package jiraRestAPI;

import io.restassured.RestAssured;

public class BaseConfig {
	
	public void BaseURI() {
		RestAssured.baseURI = "https://dasvinrestapi.atlassian.net/rest/api/2/issue/";
	}
	
	public void Authentication() {
		RestAssured.authentication = RestAssured.preemptive().basic("dasvinkumar2404@gmail.com", "BGz5HpgpYSlVd3mH43s2DDB2");
	}

}
