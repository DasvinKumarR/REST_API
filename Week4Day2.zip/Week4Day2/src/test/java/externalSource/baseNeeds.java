package externalSource;

import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class baseNeeds {

	protected static RequestSpecification request;
	protected static Response response;
	protected static String sys_value;
	
}
