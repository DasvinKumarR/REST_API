package week4Day1Assignment;

import org.testng.annotations.Test;

public class DeleteRequest extends ServicenowBaseSetup {
	
	@Test (dependsOnMethods = {"week4Day1Assignment.PutRequest.put"})
	public void delete() {
		response = request.delete("/change_request/"+sys_id);
		response.then().assertThat().statusLine("HTTP/1.1 204 No Content");
	}

}
