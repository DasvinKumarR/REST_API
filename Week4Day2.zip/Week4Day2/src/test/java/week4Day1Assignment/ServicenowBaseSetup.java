package week4Day1Assignment;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class ServicenowBaseSetup {
	
	static RequestSpecification request;
	static Response response;
	static String sys_id;
	
	@BeforeMethod
	public void beforeRequest() {
		RestAssured.baseURI = "https://dev140626.service-now.com/api/now/table/";
		RestAssured.authentication = RestAssured.basic("admin", "YaO9-A0opfR*");
		request = RestAssured.given().contentType(ContentType.JSON).log().all();
	}
	
	@AfterMethod
	public void afterRequest() {
		response.then().log().all();
	}

}
