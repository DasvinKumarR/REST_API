package week4Day1Assignment;

import org.hamcrest.Matchers;
import org.testng.annotations.*;

public class GetRequest extends ServicenowBaseSetup {
	
	@Test (dependsOnMethods = {"week4Day1Assignment.PostRequest.post"})
	public void GetCreatedData() {
		response = request.get("/change_request/"+sys_id);
		response.then().assertThat().statusCode(200);
		response.then().assertThat().body("result.sys_id", Matchers.containsString(sys_id));
	}

}
