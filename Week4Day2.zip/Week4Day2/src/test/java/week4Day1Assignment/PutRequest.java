package week4Day1Assignment;

import org.hamcrest.Matchers;
import org.testng.annotations.Test;

public class PutRequest extends ServicenowBaseSetup {

	@Test (dependsOnMethods = {"week4Day1Assignment.PostRequest.post"})
	public void put() {
		request.when().body("{\r\n"
				+ "    \"short_description\":\"using put method for hemcrest\"\r\n"
				+ "}");
		response = request.put("/change_request/"+sys_id);
		response.then().assertThat().statusCode(200);
		response.then().assertThat().body("result.short_description", Matchers.equalTo("using put method for hemcrest"));
	}
	
}
