package week4Day1Assignment;

import org.hamcrest.Matchers;
import org.testng.annotations.Test;


public class PostRequest extends ServicenowBaseSetup {

	@Test
	public void post() {
		request.when().body("{\r\n"
				+ "    \"short_description\":\"My first record in api change request table\",\r\n"
				+ "    \"description\":\"10win created the this record for practice purpose\",\r\n"
				+ "    \"category\" : \"software\"\r\n"
				+ "}");
		response = request.post("/change_request");
		response.then().assertThat().statusCode(201);
		response.then().assertThat().body("result.description", Matchers.containsString("10win created the this record for practice purpose"));
		sys_id = response.body().jsonPath().getString("result.sys_id");
	}
	
}
