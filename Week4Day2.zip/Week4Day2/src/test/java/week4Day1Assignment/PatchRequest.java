package week4Day1Assignment;

import org.hamcrest.Matchers;
import org.testng.annotations.Test;

public class PatchRequest extends ServicenowBaseSetup{
	
	@Test (dependsOnMethods = {"week4Day1Assignment.PostRequest.post"})
	public void patch() {
		request.when().body("{\r\n"
				+ "    \"description\":\"using patch method for hamcrest\"\r\n"
				+ "}");
		response = request.patch("/change_request/"+sys_id);
		response.then().assertThat().statusCode(200);
		response.then().assertThat().body("result.description", Matchers.equalTo("using patch method for hamcrest"));
	}

}
