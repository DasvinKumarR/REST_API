package hooks;

import io.cucumber.java.Before;
import io.restassured.RestAssured;

public class Setup {
	
	@Before
	public void BaseConfig() {
		System.out.println("Hi Dasvin!");
		RestAssured.baseURI = "https://dev140626.service-now.com/api/now/table/";
		RestAssured.authentication = RestAssured.basic("admin", "YaO9-A0opfR*");
	}

}
