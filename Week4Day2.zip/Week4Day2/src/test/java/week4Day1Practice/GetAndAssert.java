package week4Day1Practice;

import org.hamcrest.Matchers;
import org.testng.annotations.Test;

public class GetAndAssert extends ServiceNowConfig {

	@Test
	public void getAndAssert() {
		response = request.get("/change_request");
		response.then().assertThat().statusCode(200);
		response.then().assertThat().body("result[0].number", Matchers.containsString("CHG0000024"));
		response.then().assertThat().body("result.number", Matchers.hasItem("CHG0000024"));
	}
	
}
