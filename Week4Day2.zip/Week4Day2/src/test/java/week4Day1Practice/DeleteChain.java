package week4Day1Practice;

import org.testng.annotations.*;

public class DeleteChain extends ServiceNowConfig {

	@Test (dependsOnMethods = {"week4Day1Practice.DiffPostRequestMethod.createWithString"})
	public void deleteChaining() {
		response = request.delete("/change_request/"+sys_id);
		response.then().assertThat().statusCode(204);
	}
	
}
