package week4Day1Practice;

import java.io.File;

import org.hamcrest.Matchers;
import org.testng.annotations.Test;

public class DiffPostRequestMethod extends ServiceNowConfig {

	@Test
	public void createWithString() {
		request.body("{\r\n"
				+ "    \"short_description\":\"My first record in api change request table\",\r\n"
				+ "    \"description\":\"10win created the this record for practice purpose\",\r\n"
				+ "    \"category\" : \"Software\"\r\n"
				+ "}");
		response = request.post("/change_request");
		response.then().assertThat().statusCode(201);
		response.then().assertThat().body("result.category", Matchers.equalTo("Software"));
		sys_id = response.body().jsonPath().getString("result.sys_id");
		System.out.println(sys_id);
	}
	
	@Test
	public void createWithFile() {
		File file = new File("./src/test/resources/serviceData.json");
		request.body(file);
		response = request.post("/change_request");
		response.then().assertThat().statusCode(201);
		response.then().assertThat().body("result.category", Matchers.equalTo("Software"));
	}

}
