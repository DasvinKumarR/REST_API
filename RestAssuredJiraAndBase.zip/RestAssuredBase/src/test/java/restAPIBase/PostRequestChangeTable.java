package restAPIBase;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class PostRequestChangeTable {
	
	@Test
	public void PostRequest() {
		//BaseURI end point
		RestAssured.baseURI = "https://dev140626.service-now.com/api/now/table/";
		
		//Authentication
		RestAssured.authentication = RestAssured.basic("admin", "YaO9-A0opfR*");
		
		//Body Construct
		RequestSpecification RequestBody = RestAssured.given().contentType("application/json").when().body("{\r\n"
				+ "    \"short_description\":\"My first record in api change request table\",\r\n"
				+ "    \"description\":\"10win created the this record for practice purpose\"\r\n"
				+ "}");
		
		// Send Request
		Response res = RequestBody.post("change_request");
		
		//Assertion
		res.then().assertThat().statusCode(201);
		
		//Response code and Body
		System.out.println("Status Code " + res.getStatusCode());
		res.prettyPrint();
	}

}
