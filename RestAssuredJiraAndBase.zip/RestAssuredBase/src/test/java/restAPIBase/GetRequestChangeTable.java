package restAPIBase;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class GetRequestChangeTable {
	
	@Test
	public void GetRequest() {
		
			//BaseURI end point
			RestAssured.baseURI = "https://dev140626.service-now.com/api/now/table/";
			
			//Authentication
			RestAssured.authentication = RestAssured.basic("admin", "YaO9-A0opfR*");
			
			//Body Construct
			RequestSpecification RequestBody = RestAssured.given();
			
			// Send Request
			Response res = RequestBody.get("change_request");
			
			// assertion
			res.then().assertThat().statusCode(200);
			
			//Response code and Body
			System.out.println("Status Code " + res.getStatusCode());
			//res.prettyPrint();
	
		}
	}
