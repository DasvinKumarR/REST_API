package restAPIBase;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class DeleteRequestChangeTable {
	
	@Test
	public void DeleteRequest() {
		//BaseURI end point
		RestAssured.baseURI = "https://dev140626.service-now.com/api/now/table/";
		
		//Authentication
		RestAssured.authentication = RestAssured.basic("admin", "YaO9-A0opfR*");
		
		//Body Construct
		RequestSpecification RequestBody = RestAssured.given();
		
		// Send Request
		Response res = RequestBody.delete("change_request/63db368297b861103579b8dfe153af2b");
		
		//Assertion
		res.then().assertThat().statusCode(204);
		
		//Response code and Body
		System.out.println("Status Code " + res.getStatusCode());
		res.prettyPrint();
		
	}

}
