package restAPIBase;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class GetRequestWithParams {
	
	@Test
	public void GetRequestParams() {
		//BaseURI end point
		RestAssured.baseURI = "https://dev140626.service-now.com/api/now/table/";
		
		//Authentication
		RestAssured.authentication = RestAssured.basic("admin", "YaO9-A0opfR*");
		
		//Body Construct
		RequestSpecification RequestBody = RestAssured.given().queryParam("sysparm_fields", "number,sys_id,short_description");
		
		// Send Request
		Response res = RequestBody.get("change_request");
		
		//Assertion
		res.then().assertThat().statusCode(200);
		
		//Response code and Body
		System.out.println("Status Code " + res.getStatusCode());
		res.prettyPrint();
		
	}

}
