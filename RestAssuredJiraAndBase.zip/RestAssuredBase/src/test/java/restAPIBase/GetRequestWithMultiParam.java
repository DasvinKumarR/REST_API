package restAPIBase;

import java.util.HashMap;
import java.util.Map;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class GetRequestWithMultiParam {

	@Test
	public void GetRequestMultiParams() {
		//BaseURI end point
		RestAssured.baseURI = "https://dev140626.service-now.com/api/now/table/";
		
		//Authentication
		RestAssured.authentication = RestAssured.basic("admin", "YaO9-A0opfR*");
		
		//Map
		Map<String, String> MultiQuery = new HashMap<String, String>();
		MultiQuery.put("sysparm_fields", "number,sys_id,short_description");
		//Body Construct
		RequestSpecification RequestBody = RestAssured.given().queryParams(MultiQuery);
		
		// Send Request
		Response res = RequestBody.get("change_request");
		
		//Assertion
		res.then().assertThat().statusCode(200);
		
		//Response code and Body
		System.out.println("Status Code " + res.getStatusCode());
		res.prettyPrint();
	}
}
