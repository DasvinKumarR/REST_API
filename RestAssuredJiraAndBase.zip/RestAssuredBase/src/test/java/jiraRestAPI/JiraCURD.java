package jiraRestAPI;

import org.testng.annotations.Test;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class JiraCURD extends BaseConfig{
	
	String IdValue;
	
	@Test (priority = 1)
	public void postRequest() {
		BaseURI();
		Authentication();
		RequestSpecification requestBody = RestAssured.given().contentType("application/json").body("{\r\n"
				+ "    \"fields\": {\r\n"
				+ "        \"project\": {\r\n"
				+ "            \"key\": \"DS\"\r\n"
				+ "        },\r\n"
				+ "        \"summary\": \"Defect Raised by Dasvin\",\r\n"
				+ "        \"description\": \"Hi this is dasvin raised defect.\",\r\n"
				+ "        \"issuetype\": {\r\n"
				+ "            \"name\": \"Bug\"\r\n"
				+ "        }\r\n"
				+ "    }\r\n"
				+ "}");
		
		//Send Request
		Response res = requestBody.post();
		
		//Extract Id
		JsonPath Path = res.jsonPath();
		Long IdKey = Path.getLong("id");
		IdValue = IdKey.toString();
		System.out.println("Created issue Id is " + IdKey);
		
		//Assertion
		res.then().assertThat().statusCode(201);
		res.prettyPrint();
	}
	
	@Test (priority = 2)
	public void getRequest() {
		BaseURI();
		Authentication();
		RequestSpecification requestBody = RestAssured.given();
		//Send Request
		Response res = requestBody.get(IdValue);
		//Assert
		res.then().assertThat().statusCode(200);
		res.prettyPrint();
	}
	
	@Test (priority = 3)
	public void putRequest() {
		BaseURI();
		Authentication();
		RequestSpecification requestBody = RestAssured.given().contentType("application/json").body("{\r\n"
				+ "    \"fields\": {\r\n"
				+ "        \"project\": {\r\n"
				+ "            \"key\": \"DS\"\r\n"
				+ "        },\r\n"
				+ "        \"summary\": \"Update in Defect Raised by Dasvin\",\r\n"
				+ "        \"description\": \"Hi this is dasvin made updation in raised defect.\",\r\n"
				+ "        \"issuetype\": {\r\n"
				+ "            \"name\": \"Bug\"\r\n"
				+ "        }\r\n"
				+ "    }\r\n"
				+ "}");
		
		//Send Request
		Response res = requestBody.put(IdValue);
		
		//Assertion
		System.out.println("Put Response Code " + res.getStatusCode());
		res.then().assertThat().statusCode(204);
	}
	
	@Test (priority = 4)
	public void deleteRequest() {
		BaseURI();
		Authentication();
		RequestSpecification requestBody = RestAssured.given();
		//Send Request
		Response res = requestBody.delete(IdValue);
		//Assert
		System.out.println("Delete Response Code " + res.getStatusCode());
		res.then().assertThat().statusCode(204);
		
	}

}
